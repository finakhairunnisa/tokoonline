<!DOCTYPE html>
<html>
<head>
     <title>BIODATA DIRI</title>
</head>
<body>
<h3>Tambah Data Biodata</h3>
<form action="<?= base_url('http://localhost/fina/tambah'); ?>" method="post">
    <input type="text" name="nama" placeholder="Nama" required>
    <input type="text" name="tempat_lahir" placeholder="Tempat Lahir" required>
    <input type="date" name="tgl_lahir" required>
    <input type="text" name="agama" placeholder="Agama" required>
    <input type="text" name="alamat" placeholder="Alamat" required>
    <button type="submit">Tambah</button>
</form>
<br>
     <table border="1px solid black">
     <tr>
          <th>NAMA </th>
          <th>TEMPAT LAHIR</th>
          <th>TANGGAL LAHIR </th>
          <th>AGAMA </th>
          <th>ALAMAT</th>
          <th colspan="2">AKSI</th>
     </tr>

     <?php foreach ((array) $biodata_fina as $fina) : ?>
          <tr>
             <td><?php echo $fina['nama']; ?></td>
             <td><?php echo $fina['tempat_lahir']; ?></td>
             <td><?php echo $fina['tgl_lahir']; ?></td>
             <td><?php echo $fina['agama']; ?></td>
             <td><?php echo $fina['alamat']; ?></td>
             <td><div class="btn btn-danger"><i class="fa fa-trash"></i></div></td>
          </tr>
     <?php endforeach; ?>
     </table>

</body>
</html>
