<div class="container-fluid mt-4" style="margin-left: 250px;">
    <h4>Keranjang Belanja</h4>

    <table class="table table-dark table-striped">
        <tr>
            <th style="width: 10%;">No</th>
            <th style="width: 20%;">Nama Produk</th>
            <th style="width: 20%;">Jumlah</th>
            <th style="width: 20%;">Harga</th>
            <th >Sub-Total</th>
        </tr>

        <?php
        $no=0;
        foreach ($this->cart->contents() as $items) : ?>

        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $items['name'] ?></td>
            <td><?php echo $items['qty'] ?></td>
            <td><?php echo $items['price'] ?></td>
            <td><?php echo $items['subtotal'] ?></td>
        </tr>

       <?php endforeach; ?>


</table>
</div>
        