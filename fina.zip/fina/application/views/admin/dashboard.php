<div class="container-fluid" style="margin-left: 250px; ">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <div class="row">
            <!-- Statistik Cards -->
            <div class="col-sm-6 col-md-4 col-lg-2 mb-3">
              <div class="bg-dark p-3 text-white text-center rounded">
                <i class="mdi mdi-cart fs-3 mb-1"></i>
                <h5 class="mb-0 mt-1">656</h5>
                <small class="font-light">Total Shop</small>
              </div>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2 mb-3">
              <div class="bg-dark p-3 text-white text-center rounded">
                <i class="mdi mdi-tag fs-3 mb-1"></i>
                <h5 class="mb-0 mt-1">9540</h5>
                <small class="font-light">Total Orders</small>
              </div>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2 mb-3">
              <div class="bg-dark p-3 text-white text-center rounded">
                <i class="mdi mdi-table fs-3 mb-1"></i>
                <h5 class="mb-0 mt-1">100</h5>
                <small class="font-light">Pending Orders</small>
              </div>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-2 mb-3">
              <div class="bg-dark p-3 text-white text-center rounded">
                <i class="mdi mdi-web fs-3 mb-1"></i>
                <h5 class="mb-0 mt-1">8540</h5>
                <small class="font-light">Online Orders</small>
              </div>
            </div>
            <!-- End Statistik Cards -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
