<div class="container-fluid" style="margin-left: 250px; ">
  <div class="row">

    <?php foreach ($barang as $brg) : ?>
      <div class="card ml-3 mb-4" style="width: 16rem;">
        <img 
          src="<?php echo base_url('uploads/' . $brg->gambar); ?>" 
          class="card-img-top" 
          alt="<?php echo $brg->nama_brg; ?>"
          style="height: 200px; object-fit: contain; background: #f8f9fa;">

        <div class="card-body">
          <h5 class="card-title mb-1"><?php echo $brg->nama_brg; ?></h5>
          <small><?php echo $brg->keterangan; ?></small><br>
          <small class="text-muted"><?php echo $brg->kategori; ?></small><br>
          <span style="color: red; background: yellow; font-size: 18px;">Rp. <?php echo $brg->harga; ?></span>
          <?php echo anchor('dashboard/tambah_ke_keranjang/'.$brg->id_brg,'<div class="btn btn-sm btn-primary">Tambah ke Keranjang</div>')?>
          <a href="#" class="btn btn-success btn-sm">Detail</a>
        </div>
      </div>
    <?php endforeach; ?>

  </div>
</div>
