<?php

class Fina extends CI_Controller {


    public function __construct() {
        parent::__construct();
        $this->load->helper('url'); 
    }
    public function index() {
    $this->load->model('model_fina');
    $data['biodata_fina']= $this->model_fina->get_data();

    $this->load->view('views_fina', $data);
    }

    public function tambah() {
        $this->load->model('model_fina');
    
        $data = [
            'nama' => $this->input->post('nama'),
            'tempat_lahir' => $this->input->post('tempat_lahir'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'agama' => $this->input->post('agama'),
            'alamat' => $this->input->post('alamat'),
        ];
    
        $this->model_fina->insert_data($data);
        redirect('fina');
    }
}
?>