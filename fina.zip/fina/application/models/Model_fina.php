<?php 

class Model_fina extends CI_Model {
  public function get_data()
{
  return $this->db->get('biodata_fina')->result_array();
}

public function insert_data($data) {
  return $this->db->insert('biodata_fina', $data);
}

}


 ?>